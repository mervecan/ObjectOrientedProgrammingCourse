package development;

/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */

public enum VehicleType {
	CAR,
	BUS,
	MOTORCYCLE
}
