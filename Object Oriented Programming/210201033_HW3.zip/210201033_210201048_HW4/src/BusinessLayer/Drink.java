package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */

public class Drink extends Nutrition{

	public Drink() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Drink(String name, double unit, double calorie, NutritionType type, String foodOrDrink) {
		super(name, unit, calorie, type, foodOrDrink);
		// TODO Auto-generated constructor stub
	}
	

	
	
}
