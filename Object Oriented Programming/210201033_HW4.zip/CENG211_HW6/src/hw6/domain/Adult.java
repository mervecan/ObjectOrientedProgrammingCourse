package hw6.domain;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public class Adult extends Customer{

	@Override
	public String toString() {
		return "Adult [getAge()=" + getAge() + ", getGender()=" + getGender() + ", getName()=" + getName()
				+ ", getType()=" + getType() + "]";
	}
	
}
