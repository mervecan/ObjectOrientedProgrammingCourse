package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */

public class Food extends Nutrition {

	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Food(String name, double unit, double calorie, NutritionType type, String foodOrDrink) {
		super(name, unit, calorie, type, foodOrDrink);
		// TODO Auto-generated constructor stub
	}

	

}
