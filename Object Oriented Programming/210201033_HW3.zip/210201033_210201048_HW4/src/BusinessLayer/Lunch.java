package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public class Lunch extends Meal{

	@Override
	public double totalCalorie() {
		// TODO Auto-generated method stub
		return 0;
	}

}
