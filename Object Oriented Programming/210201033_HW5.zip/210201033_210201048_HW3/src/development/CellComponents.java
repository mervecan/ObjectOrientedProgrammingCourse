package development;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public enum CellComponents {
	WALL,
	APERTURE,
	EXIT
}
