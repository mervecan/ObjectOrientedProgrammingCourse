package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public class Breakfast extends Meal {
	

	@Override
	public double totalCalorie() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
