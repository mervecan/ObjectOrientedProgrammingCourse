package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public enum DepartmentName {
	COMPUTER_SCIENCE,
	PHYSICS,
	MATH,
	CHEMISTRY,
	
}
