
public  enum Genre {
   SCIENCE,
   DRAMA,
   ADVENTURE,
   HORROR,
   HISTORY,
   COMICS;
	
 }

