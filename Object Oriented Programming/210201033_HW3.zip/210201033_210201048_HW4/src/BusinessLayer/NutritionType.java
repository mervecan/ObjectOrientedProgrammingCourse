package BusinessLayer;
/**
 * 
 * @author Merve Can - T�rkan Demirci, 210201033 - 210201048
 *
 */
public enum NutritionType {
	CEREAL,
	MEATS,
	DAIRY_PRODUCT,
	FRUITS,
	FISH,
	VEGETABLES
	
	
}
